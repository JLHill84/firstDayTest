def my_favorite_animal
    "cat"
  end
   
  best_animal = my_favorite_animal
   
  puts best_animal