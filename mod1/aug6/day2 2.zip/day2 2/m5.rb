def rude_greeting(name=nil)
 name ||= "you jerk"
 puts "Hey there, #{name}"
end

rude_greeting()