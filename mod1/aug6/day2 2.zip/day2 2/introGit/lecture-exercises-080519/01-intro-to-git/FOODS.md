# Favorite Foods

* Jun: Apple
* Richard: Hamburgers
* Emily: raspberries
* Israel: Seafood
* Resham: Pizza
* Josh: Pasta
* Michael: Sweet Potato Fries
* Barrette: Salmon
* Jade: Rice and Beans
* Kevin: pasta
* Max: Cheeseburger
* Chandon: Cheese Cake
* Chase: Seafood Pasta
* Leslie: Guacamoles
