myString = "Welcome,to,Flatiron!"
puts myString.split(',').count